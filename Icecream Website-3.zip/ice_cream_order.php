<?php
session_start();
?>
<!DOCTYPE HTML>
<html>
<head>
<title> Order Display Page </title>
<style>
a	{ 
	  font-family: Lucida Handwriting; 
	  font-size: 100%;
}
a:link {
    color: Green;
    background-color: transparent;
    text-decoration: none;
}
a:hover {
    color: Red;
    background-color: transparent;
    text-decoration: underline;
}
a:active {
    color: Yellow;
    background-color: transparent;
    text-decoration: underline;
}
p { 
	  font-family: Monotype Corsiva;
	  font-size: 200%;
}
h4 { 
	  font-family: Times New Roman;
	  font-size: 150%;
}
</style>
</head>
<body bgcolor="#EED2EE">
<form action="report.php" method="POST">
<div id= "menu" align="right">
<a href= "http://cs.ucmo.edu/~cxr26300/welcomepage.html"> Rampally's Ice Cream </a> |
<a href= "http://cs.ucmo.edu/~cxr26300/contactus.html"> CONTACT </a> |
<a href= "http://cs.ucmo.edu/~cxr26300/aboutus.html"> ABOUT </a>
</div>
<center>
<p> Orders </p>
</center>
<h4>
<?php
$tim=date("H:i:sa");
$dat = date("H:i:sa" ,strtotime("+15 minutes"));
$ddat = date("H:i:sa", strtotime("+30 minutes"));
$jd= cal_to_jd(CAL_GREGORIAN,date("m"),date("d"),date("Y"));
$week= jddayofweek($jd,1);

$email = $_POST['EMail'];

$servername = "www.math-cs.ucmo.edu";
$username = "test";
$password = "test";
$database = "test";
$conn = new mysqli($servername, $username, $password, $database);
if($conn->connect_error){
	die("Connection failed: " . $conn->connect_error);
}
echo "Connected Successfully";
echo nl2br(" \n ");
$display="CREATE TABLE cxr26300_orders(sno int(20) NOT NULL auto_increment, cone varchar(50), 
milkshake varchar(50), floats varchar(50), email varchar(50), order_time time, preparation_time time, 
delivered_time time,week varchar(50), primary key(sno))";
if ($conn->query($display) === TRUE) {
    echo "Table cxr26300_orders created successfully";
	echo nl2br(" \n ");
} 
$iorder = "INSERT INTO cxr26300_orders(sno, cone, milkshake, floats, email, order_time, preparation_time, 
delivered_time, week) VALUES ('', 'ice cream', '', '','$email', '$tim', '$dat', 
'$ddat', '$week')";
if($conn->query($iorder) === TRUE){
	echo nl2br(" \n");
	echo "New Record created successfully";
}else{
	echo "Error: " . $iorder . "<br>" . $conn->error;
}
$result = mysqli_query($conn,"SELECT * FROM `cxr26300_orders` ;");
while($row = mysqli_fetch_assoc($result)){
?>
<table>
<tr>
<td><?php echo $row["sno"]; ?> </td>
<td></td>
<td></td>
<td></td>
<td></td>
<td><?php echo $row["cone"]; ?> </td>
<td></td>
<td></td>
<td></td>
<td></td>
<td><?php echo $row["milkshake"]; ?> </td>
<td></td>
<td></td>
<td></td>
<td></td>
<td><?php echo $row["floats"]; ?> </td>
<td></td>
<td></td>
<td></td>
<td></td>
<td><?php echo $row["email"]; ?> </td>
<td></td>
<td></td>
<td></td>
<td></td>
<td><?php echo $row["order_time"]; ?> </td>
<td></td>
<td></td>
<td></td>
<td></td>
<td><?php echo $row["preparation_time"]; ?> </td>
<td></td>
<td></td>
<td></td>
<td></td>
<td><?php echo $row["delivered_time"]; ?> </td>
<td></td>
<td></td>
<td></td>
<td></td>
<td><?php echo $row["week"]; ?> </td>
<td></td>
<td></td>
<td></td>
<td></td>
<td> <input type="checkbox" name="del" value="del"> Delivered</td>
</tr>
</table>
<?php
}
?>
</h4>
<center>
<button type="submit"> Report </button>
</center>
</form>
</body>
</html>