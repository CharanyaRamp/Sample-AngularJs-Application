<?php
session_start();
?>
<!DOCTYPE HTML>
<html>
<head>
<title> Report Page </title>
<style>
a	{ 
	  font-family: Lucida Handwriting; 
	  font-size: 100%;
}
a:link {
    color: Green;
    background-color: transparent;
    text-decoration: none;
}
a:hover {
    color: Red;
    background-color: transparent;
    text-decoration: underline;
}
a:active {
    color: Yellow;
    background-color: transparent;
    text-decoration: underline;
}
h1 { 
	  font-family: Monotype Corsiva;
	  font-size: 200%;
}
h4 { 
	  font-family: Arial Narrow;
	  font-size: 150%;
}
</style>
</head>
<body bgcolor="#ADDFFF">
<div id= "menu" align="right">
<a href= "http://cs.ucmo.edu/~cxr26300/welcomepage.html"> Rampally's Ice Cream </a> |
<a href= "http://cs.ucmo.edu/~cxr26300/contactus.html"> CONTACT </a> |
<a href= "http://cs.ucmo.edu/~cxr26300/aboutus.html"> ABOUT </a>
</div>
<center>
<h1>Rampally's Ice Cream Sales Reports</h1>
</center> 
<h4>
<?php
$servername = "www.math-cs.ucmo.edu";
$username = "test";
$password = "test";
$database = "test";
$conn = new mysqli($servername, $username, $password, $database);
if($conn->connect_error){
	die("Connection failed: " . $conn->connect_error);
}
echo "Connected Successfully";
echo nl2br(" \n ");
echo nl2br(" \n ");
echo nl2br(" \n ");
echo "Sales based on Variety";
echo nl2br(" \n ");
?>
<table>
<tr>
<td><?php $NS = mysqli_query($conn,"SELECT COUNT(*) AS 'SC' FROM cxr26300_orders 
WHERE cone='ice cream';");
$row = mysqli_fetch_assoc($NS);
echo "Total Number of Ice cream Orders:" .$row["SC"]; ?></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td><?php $CTS = mysqli_query($conn,"SELECT COUNT(*) AS 'SC' FROM cxr26300_orders 
WHERE milkshake='milkshake';");
$row = mysqli_fetch_assoc($CTS);
echo "Total Number of milkshake Orders:" .$row["SC"]; ?></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td><?php $CGPS = mysqli_query($conn,"SELECT COUNT(*) AS 'SC' FROM cxr26300_orders 
WHERE floats='floats';");
$row = mysqli_fetch_assoc($CGPS);
echo "Total Number of floats Orders:" .$row["SC"]; ?></td>
</tr></table>
<?php 
echo nl2br(" \n ");
echo nl2br(" \n ");
echo nl2br(" \n ");
echo "Sales on Week Days";
echo nl2br(" \n "); 
?>
<table>
<tr>
<td><?php $Mon = mysqli_query($conn,"SELECT COUNT(*) AS WC FROM cxr26300_orders 
WHERE week='monday';");
$row = mysqli_fetch_assoc($Mon);
echo "Monday:" .$row["WC"]; ?></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td><?php $Tue = mysqli_query($conn,"SELECT COUNT(*) AS WC FROM cxr26300_orders 
WHERE week='tuesday';");
$row = mysqli_fetch_assoc($Tue);
echo "Tuesday:" .$row["WC"]; ?></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td><?php $Wed = mysqli_query($conn,"SELECT COUNT(*) AS WC FROM cxr26300_orders 
WHERE week='wednesday';");
$row = mysqli_fetch_assoc($Wed);
echo "Wednesday:" .$row["WC"]; ?></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td><?php $Thurs = mysqli_query($conn,"SELECT COUNT(*) AS WC FROM cxr26300_orders 
WHERE week='thursday';");
$row = mysqli_fetch_assoc($Thurs);
echo "Thursday:" .$row["WC"]; ?></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td><?php $Fri = mysqli_query($conn,"SELECT COUNT(*) AS WC FROM cxr26300_orders 
WHERE week='friday';");
$row = mysqli_fetch_assoc($Fri);
echo "Friday:" .$row["WC"]; ?></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td><?php $Sat = mysqli_query($conn,"SELECT COUNT(*) AS WC FROM cxr26300_orders 
WHERE week='saturday';");
$row = mysqli_fetch_assoc($Sat);
echo "Saturday:" .$row["WC"]; ?></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td><?php $Sun = mysqli_query($conn,"SELECT COUNT(*) AS WC FROM cxr26300_orders 
WHERE week='sunday';");
$row = mysqli_fetch_assoc($Sun);
echo "Sunday:" .$row["WC"]; ?></td>
</tr></table>
<?php 
echo nl2br(" \n ");
echo nl2br(" \n ");
echo nl2br(" \n ");
$diff = mysqli_query($conn,"SELECT order_time, preparation_time, 
TIMEDIFF(preparation_time, order_time) AS Difference FROM cxr26300_orders;");
$row = mysqli_fetch_assoc($diff);
echo "The Length of the Time between Ordered and Prepared: " .$row["Difference"];
echo nl2br(" \n ");
echo nl2br(" \n ");
$differences = mysqli_query($conn,"SELECT preparation_time, delivered_time,
TIMEDIFF(delivered_time, preparation_time) AS Difference FROM cxr26300_orders;");
$row = mysqli_fetch_assoc($differences);
echo "The Length of the Time between prepared and delivered: " .$row["Difference"];
?>
 </h4>
</body>
</html>